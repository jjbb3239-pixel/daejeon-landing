import { useState } from "react";
import MoodCoursePage from "./MoodCoursePage";

export default function App() {
  const [count, setCount] = useState(0);
  const [view, setView] = useState<"home" | "mood">("home");

  if (view === "mood") {
    return (
      <div className="dj-page" translate="no">
        <MoodCoursePage
          onBack={() => {
            setView("home");
            window.scrollTo(0, 0);
          }}
        />
      </div>
    );
  }

  function findDream() {
    setCount((prev) => {
      const next = prev < 5 ? prev + 1 : prev;
      if (next === 5 && prev !== 5) {
        setTimeout(() => {
          alert("🎉 꿈돌이를 전부 찾았습니다!\n이제 대전 갈 준비도 거의 완료.");
        }, 150);
      }
      return next;
    });
  }

  return (
    <div className="dj-page" translate="no">
      {/* 새 티켓형 1P */}
      <section className="hero">
        <div className="ticket">
          {/* 왼쪽 */}
          <div className="ticket-left">
            <div className="eyebrow">🎫 오늘 기분으로 떠나는 대전</div>

            <h1>
              오늘 기분,
              <br />
              어떤가요?
            </h1>

            <p className="description">
              기분을 몇 개 골라주세요.
              <br />
              지금의 당신과 어울리는 대전 장소를 찾아
              <br />
              하루 코스로 묶어드릴게요.
              <br />
              <br />
              <strong>어디 갈지는 저희가 고민할게요.</strong>
            </p>

            <div className="route">
              <div className="station">
                <small>FROM</small>
                <strong>지금 내 기분</strong>
              </div>

              <div className="line">
                <span className="train">🚆</span>
              </div>

              <div className="station">
                <small>TO</small>
                <strong>오늘의 대전</strong>
              </div>
            </div>

            <a href="#choose" className="cta">
              내 기분 태그 만들기 →
            </a>
          </div>

          {/* 오른쪽 */}
          <div className="ticket-right">
            <div className="ticket-number">MOOD → DAEJEON · 2026</div>

            <div className="character-area">
              <div className="dream">👽</div>

              <div className="note">
                TEAM 대전술사가 열심히 그렸습니다.
                <br />
                오늘 기분은 잘 맞혀볼게요.
              </div>
            </div>

            <div className="small-copy">
              * 실제 승차권은 아니지만 대전 갈 핑계로는 쓸 수 있습니다.
            </div>
          </div>
        </div>
      </section>

      {/* INTERRUPTION */}
      <section className="interrupt">
        <div className="container">
          <strong>대전</strong>

          <h2>
            얼마나 재미있을 지<br />
            감도 안 옴;;
          </h2>

          <p>
            괜찮아요.
            <br />
            저희도 처음에는 <b>성심당밖에 몰랐습니다.</b>
          </p>

          <p>그래서 직접 찾아봤어요 ↓</p>
        </div>
      </section>

      {/* CHOOSE */}
      <section id="choose">
        <div className="container">
          <h2>
            오늘의 기분을
            <br />
            골라주세요
          </h2>

          <div className="cards">
            <div className="card">
              <div className="emoji">📸</div>
              <h3>오늘 피드 좀 채워볼까?</h3>
              <p>찍는 곳마다 그림 되는 대전 인생샷 스팟들.</p>
            </div>

            <div className="card">
              <div className="emoji">🍽️</div>
              <h3>맛집 도장깨기</h3>
              <p>하나씩 찍어먹으며 도장 채우는 대전 느좋 블루리본 맛집 순례.</p>
            </div>

            <div className="card">
              <div className="emoji">☕</div>
              <h3>기분에 따라 고르는 카페</h3>
              <p>오늘 무드에 딱 맞는 대전 카페 추천.</p>
            </div>

            <div
              className="card"
              role="button"
              tabIndex={0}
              style={{ cursor: "pointer" }}
              onClick={() => {
                setView("mood");
                window.scrollTo(0, 0);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setView("mood");
                  window.scrollTo(0, 0);
                }
              }}
            >
              <div className="emoji">🌌</div>
              <h3>혼자 감수성 터지는 날</h3>
              <p>혼자 걷고 사색하기 좋은 대전 감성 스팟. →</p>
            </div>
          </div>
        </div>
      </section>

      {/* PLACES */}
      <section>
        <div className="container">
          <h2>
            그럼 일단
            <br />
            여기부터 가봅시다.
          </h2>

          <div className="place">
            <h2>🍞 성심당</h2>
            <h3>일단 빵부터 먹읍시다.</h3>
            <p>대전에 와서 성심당을 안 가는 것도 자유지만...</p>
            <p>굳이 그럴 필요가 있을까요?</p>
            <span className="mission">미션 : 빵 하나만 사려고 들어가보기</span>
          </div>

          <div className="place">
            <h2>🌳 한밭수목원</h2>
            <h3>배부르면 좀 걸어야죠.</h3>
            <p>도심 한가운데인데 갑자기 여행 온 느낌이 납니다.</p>
            <p>걷다가 지치면 그냥 벤치에 앉아 있어도 됩니다.</p>
            <span className="mission">미션 : 제일 마음에 드는 나무 찍기</span>
          </div>

          <div className="place">
            <h2>👽 엑스포과학공원</h2>
            <h3>꿈돌이의 고향에 오셨습니다.</h3>
            <p>
              대전 사람들에게는 익숙하지만 처음 온 사람에게는 은근히 신기한 곳.
            </p>
            <span className="mission">미션 : 꿈돌이랑 사진 남기기</span>
          </div>
        </div>
      </section>

      {/* COURSE */}
      <section className="course">
        <div className="container">
          <h2>
            계획 세우기
            <br />
            귀찮죠?
          </h2>

          <p>그래서 그냥 저희가 하나 짰습니다.</p>

          <div className="timeline">
            <div className="time">
              <strong>11:00</strong>
              <span>🚆 대전 도착</span>
            </div>

            <div className="arrow">↓</div>

            <div className="time">
              <strong>11:20</strong>
              <span>
                🍞 성심당에서 빵 고르다가
                <br />
                생각보다 오래 있음
              </span>
            </div>

            <div className="arrow">↓</div>

            <div className="time">
              <strong>13:00</strong>
              <span>🌳 한밭수목원 산책</span>
            </div>

            <div className="arrow">↓</div>

            <div className="time">
              <strong>15:30</strong>
              <span>👽 엑스포에서 꿈돌이 발견</span>
            </div>

            <div className="arrow">↓</div>

            <div className="time">
              <strong>18:00</strong>
              <span>🍜 맛있는 거 먹기</span>
            </div>

            <div className="arrow">↓</div>

            <div className="time">
              <strong>20:00</strong>
              <span>
                "대전 생각보다 괜찮네?"
                <br />
                하면서 집 가기
              </span>
            </div>
          </div>

          <h2>
            이 정도면
            <br />
            이번 주말에 갈 수 있겠는데요?
          </h2>
        </div>
      </section>

      {/* GAME */}
      <section className="game">
        <div className="container">
          <h2>잠깐. 꿈돌이가 숨어있습니다.</h2>

          <p>홈페이지 어딘가에 꿈돌이 5마리가 숨어있다고 치겠습니다.</p>

          <p className="small">
            아직 개발자가 숨기지는 않았습니다. 곧 숨길 예정입니다.
          </p>

          <div className="counter">
            <span>{`👽 ${count} / 5`}</span>
          </div>

          <button className="find-button" onClick={findDream}>
            일단 꿈돌이 한 마리 찾기
          </button>
        </div>
      </section>

      {/* STUDENT STORY */}
      <section className="student">
        <div className="container student-copy">
          <h2>
            사실 이 홈페이지는
            <br />
            조금 서툽니다.
          </h2>

          <p>
            부트캠프에서 만난 교육생들이
            <br />
            대전을 소개해보고 싶어서 만들었습니다.
          </p>

          <p>
            사진 고르고,
            <br />
            꿈돌이 그리고,
            <br />
            버튼 위치 바꾸다가
            <br />
            다시 원래대로 돌려놓기도 했습니다.
          </p>

          <p>그래도 하나는 확실합니다.</p>

          <h2>
            대전,
            <br />
            생각보다 꽤 재밌습니다.
          </h2>
        </div>
      </section>

      {/* INSTAGRAM CTA */}
      <section className="instagram">
        <div className="container">
          <h2>
            대전 이야기는
            <br />
            아직 좀 더 남았습니다.
          </h2>

          <p>
            홈페이지에 넣지 못한 장소와 저희가 직접 고른 대전 스팟은
            인스타그램에 계속 올려둘게요.
          </p>

          <a className="cta" href="https://instagram.com/" target="_blank" rel="noreferrer">
            꿈돌이 따라 인스타 구경가기 ↗
          </a>

          <p className="small">팔로우까지 하면 꿈돌이가 좋아합니다.</p>
        </div>
      </section>

      <footer>
        <p>Made with ☕ + 🍞 + 약간의 시행착오</p>
        <p className="small">대전을 잘 몰랐던 사람들이 대전을 소개합니다.</p>
      </footer>
    </div>
  );
}
